package com.huntersystem.nativeapp.domain

/** Deterministic, testable, conservative selection, separate from UI. */
object Planner {
    fun plan(profile:Profile, weekday:Int, week:Int=0, previous:SessionLog=SessionLog(),
             catalog:List<Exercise> = ExerciseCatalog.exercises,
             recent:List<SessionLog> = emptyList()):DailyPlan {
        require(weekday in 0..6)
        val kind=profile.schedule.getOrNull(weekday) ?: DayType.REST
        if(kind==DayType.REST) return DailyPlan(kind,PlanStatus.REST,emptyList(),"Descanso elegido en tu calendario")
        if(profile.age<18) return DailyPlan(kind,PlanStatus.REQUIRES_REVIEW,emptyList(),"Para menores, utiliza un programa adecuado a su edad y supervisión.")
        val needsReview=profile.risk in setOf(Risk.SEVERE,Risk.ACUTE,Risk.SURGERY,Risk.UNKNOWN) ||
            (profile.risk==Risk.MODERATE && !profile.activityCleared)
        if(needsReview) return DailyPlan(kind,PlanStatus.REQUIRES_REVIEW,emptyList(),"Se conserva $kind; requiere evaluación antes de sugerir actividad automática.")
        val active=profile.injuryZones.isNotEmpty()||profile.risk!=Risk.NONE
        val available=catalog.asSequence().filter { it.category==kind }
            .filter { it.required.all(profile.equipment::contains) }
            .filter { it.involved.none(profile.injuryZones::contains) && it.supports.none(profile.injuryZones::contains) }
            .filter { !active || (it.intensity==1 && !it.impact) }
            .filter { restrictionSafe(it,profile.restrictions) }
            .filter { profile.level!=Level.BASICO || it.intensity<=1 }
            .toList()
        if(available.isEmpty()) return DailyPlan(kind,PlanStatus.NO_COMPATIBLE,emptyList(),
            "No hay ejercicios compatibles con las restricciones registradas. El día sigue siendo ${kind.label}.")
        // Variety between week/day without randomness, keeping same plan on repeated reads.
        val goals=GoalInterpreter.parse(profile.goals)
        fun score(e:Exercise):Int = when {
            GoalInterpreter.Goal.ESTHETIC in goals && e.group in setOf("Pecho","Espalda","Brazos","Hombros") -> 4
            GoalInterpreter.Goal.STRENGTH in goals && e.category==DayType.FORCE -> 3
            GoalInterpreter.Goal.AGILITY in goals && e.group.contains("piernas",ignoreCase=true) -> 2
            GoalInterpreter.Goal.CARDIO in goals && e.category==DayType.CARDIO -> 3
            GoalInterpreter.Goal.MOBILITY in goals && e.category==DayType.MOBILITY -> 3
            else -> 0
        }
        val ordered=available.sortedWith(compareByDescending<Exercise> {score(it)}.thenBy {it.group}.thenBy {it.id})
        val offset=((week*2+weekday)%ordered.size+ordered.size)%ordered.size
        val rotated=ordered.drop(offset)+ordered.take(offset)
        val selected=rotated.distinctBy { it.group }.take(if(active)3 else 5).ifEmpty { rotated.take(1) }
        val alert=recent.any { it.pain || it.fatigue || it.effort>=9 }
        val baseSets=when {
            active || previous.pain || previous.fatigue || previous.effort>=9 || alert -> 1
            week==0 -> 2
            week in 1..2 -> 3
            else -> 2
        }
        val items=selected.map { e -> Prescription(e,baseSets,
            if(e.category==DayType.CARDIO)20 else if(e.category==DayType.MOBILITY)6 else if(active)6 else 10,
            if(active)90 else if(e.category==DayType.CARDIO)45 else 60) }
        return DailyPlan(kind,PlanStatus.READY,items,if(active)"Opciones generales de menor intensidad fuera de las zonas registradas; confirma compatibilidad individual." else "Sesión basada en nivel, equipamiento y calendario.")
    }
    private fun restrictionSafe(e:Exercise,r:Set<String>):Boolean {
        if("sin-impacto" in r && e.impact)return false
        if("sin-suelo" in r && e.floor)return false
        if("solo-sentado" in r && !e.seated)return false
        if("sin-elevacion" in r && e.overhead)return false
        if("sin-cargas" in r && e.required.isNotEmpty())return false
        if("sin-manos" in r && (Zone.WRIST in e.supports))return false
        if("sin-flexion-rodilla" in r && Zone.KNEE in e.involved)return false
        if("sin-columna" in r && Zone.BACK in e.involved)return false
        return true
    }
}
