package com.huntersystem.nativeapp.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BG=Color(0xFF070D1A)
val PANEL=Color(0xFF162436)
val CYAN=Color(0xFF94C5F9)
val WHITE=Color(0xFFEBF2FF)
val MUTED=Color(0xFF9BAFC7)

private val scheme=darkColorScheme(primary=CYAN,onPrimary=BG,secondary=Color(0xFFB5A1F5),
    background=BG,onBackground=WHITE,surface=PANEL,onSurface=WHITE,outline=Color(0xFF526780))
@Composable fun HunterTheme(content:@Composable ()->Unit) {MaterialTheme(colorScheme=scheme,content=content)}

fun Modifier.hunterBorder():Modifier=this.drawBehind {
    val stroke=1.4.dp.toPx(); val m=5.dp.toPx()
    drawRoundRect(color=Color(0xFF687EA8),topLeft=Offset(m,m),
        size=androidx.compose.ui.geometry.Size(size.width-2*m,size.height-2*m),
        cornerRadius=androidx.compose.ui.geometry.CornerRadius(18.dp.toPx()), style=Stroke(stroke))
    val len=24.dp.toPx()
    for(x in listOf(m,size.width-m))for(y in listOf(m,size.height-m)) {
        val sx=if(x<size.width/2)1 else -1
        val sy=if(y<size.height/2)1 else -1
        drawLine(CYAN,Offset(x,y+sy*len),Offset(x,y),stroke)
        drawLine(CYAN,Offset(x,y),Offset(x+sx*len,y),stroke)
    }
}
@Composable fun HunterPanel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Column(modifier.background(PANEL, RoundedCornerShape(20.dp)).hunterBorder().padding(22.dp),content=content)
}
@Composable fun HunterTitle(text:String,subtitle:String?=null) {
    Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,letterSpacing=1.sp,fontSize=27.sp,color=WHITE)
    if(subtitle!=null)Text(subtitle,fontSize=12.sp,color=MUTED,letterSpacing=1.sp)
}
