package com.huntersystem.nativeapp.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class MotionMeta(val id:String,val name:String,val durationMs:Long)
data class Pt(val x:Float,val y:Float)
data class Motion(val meta:MotionMeta,val frames:List<List<Pt>>)

/** 1,000 user-provided 2D motion curves; lazily read into native Canvas, no JS runtime. */
class MotionRepository(private val context:Context) {
    suspend fun index():List<MotionMeta> = withContext(Dispatchers.IO) {
        val str=context.assets.open("motion_index.json").bufferedReader().use{it.readText()}
        val a=JSONArray(str)
        (0 until a.length()).map{ i->a.getJSONObject(i).let{ MotionMeta(it.getString("id"),it.getString("name"),it.getLong("durationMs")) } }
    }
    suspend fun motion(meta:MotionMeta):Motion?=withContext(Dispatchers.IO) {
        runCatching {
            require(meta.id.matches(Regex("[a-zA-Z0-9_-]+")))
            val str=context.assets.open("motions/${meta.id}.json").bufferedReader().use{it.readText()}
            val j=JSONObject(str);val frames=j.getJSONArray("frames")
            val poses=(0 until frames.length()).map{ i ->
                val pts=frames.getJSONArray(i)
                (0 until pts.length()).map{ k -> val p=pts.getJSONArray(k);Pt(p.getDouble(0).toFloat(),p.getDouble(1).toFloat()) }
            }
            Motion(meta.copy(durationMs=j.getLong("durationMs")),poses)
        }.getOrNull()
    }
}
