package com.huntersystem.nativeapp.domain

/** A small curated native selection for AUTO-planning, with explicit involved and support zones.
 * The 1,000 imported movement animations are browseable but NOT auto-planned until individually tagged/reviewed.
 * Joint tags are conservative software filters, NOT proof that an exercise is medically safe.
 */
object ExerciseCatalog {
    private val N=Zone.NECK;private val S=Zone.SHOULDER;private val E=Zone.ELBOW
    private val W=Zone.WRIST;private val B=Zone.BACK;private val H=Zone.HIP
    private val K=Zone.KNEE;private val A=Zone.ANKLE
    private val U=setOf(S,E,W);private val L=setOf(H,K,A)
    private fun add(id:String,name:String,t:DayType,group:String,z:Set<Zone>, support:Set<Zone> = emptySet(),
        req:Set<String> = emptySet(), intensity:Int=1, seated:Boolean=false, floor:Boolean=false,
        overhead:Boolean=false, impact:Boolean=false,steps:String=""):Exercise=
        Exercise(id,name,t,group,z,support,req,intensity,impact,seated,floor,overhead,steps,id)
    val exercises: List<Exercise> = listOf(
        add("wall","Flexión en pared",DayType.FORCE,"Pecho",U,setOf(H,K,A),steps="Apoya las palmas en una pared firme. Flexiona los brazos y vuelve con control."),
        add("pushup","Flexión de suelo",DayType.FORCE,"Pecho",U,setOf(B,H,K,A),intensity=3,floor=true),
        add("kneepush","Flexiones con rodillas apoyadas",DayType.FORCE,"Pecho",U,setOf(B,H,K),intensity=2,floor=true),
        add("press","Press de pecho en suelo",DayType.FORCE,"Pecho",U,setOf(B,H,K),req=setOf("db"),floor=true),
        add("neutral","Press con agarre neutro",DayType.FORCE,"Pecho",U,setOf(B,H,K),req=setOf("db"),floor=true),
        add("incline","Flexión inclinada",DayType.FORCE,"Pecho",U,setOf(B,H,K,A),intensity=2),
        add("seatedcurl379","Flexión de bíceps sentada",DayType.FORCE,"Brazos",setOf(E,W),setOf(H),seated=true,steps="Sentado y estable, flexiona lentamente los codos sin balancear el torso."),
        add("seatedraise379","Elevación frontal corta sentada",DayType.FORCE,"Hombros",setOf(S,E),setOf(H),seated=true,steps="Sentado, mueve los brazos solo en un recorrido cómodo."),
        add("seatedshrug379","Elevación de hombros sentada",DayType.FORCE,"Hombros",setOf(N,S),setOf(H),seated=true),
        add("curl","Curl con mancuernas",DayType.FORCE,"Brazos",setOf(E,W),setOf(H,K,A),req=setOf("db")),
        add("hammer","Curl martillo",DayType.FORCE,"Brazos",setOf(E,W),setOf(H,K,A),req=setOf("db")),
        add("row","Remo unilateral con mancuerna",DayType.FORCE,"Espalda",setOf(B,S,E,W),setOf(H,K,A),req=setOf("db")),
        add("bentrow","Remo inclinado",DayType.FORCE,"Espalda",setOf(B,S,E,W),setOf(H,K,A),req=setOf("db"),intensity=2),
        add("chair","Sentarse y levantarse",DayType.FORCE,"Piernas",L,setOf(B),steps="Usa una silla estable. Levántate y siéntate lentamente, sin forzar el recorrido."),
        add("squat","Sentadilla libre",DayType.FORCE,"Piernas",L,setOf(B),intensity=2),
        add("goblet","Sentadilla con mancuerna",DayType.FORCE,"Piernas",L,setOf(B,S,E,W),req=setOf("db"),intensity=2),
        add("bridge","Puente de glúteos",DayType.FORCE,"Cadera",setOf(B,H,K,A),floor=true),
        add("hinge","Bisagra de cadera",DayType.FORCE,"Cadera",setOf(B,H,K,A)),
        add("rdl","Peso muerto rumano",DayType.FORCE,"Cadera",setOf(B,H,K,A),setOf(S,E,W),req=setOf("db"),intensity=2),
        add("plank","Plancha abdominal",DayType.FORCE,"Core",setOf(B,H,S),setOf(E,W,K,A),floor=true,intensity=2),
        add("deadbug","Alternancia de brazos y piernas en suelo",DayType.FORCE,"Core",setOf(B,H,S,K),floor=true),
        add("bird","Extensión contralateral",DayType.FORCE,"Core",setOf(B,H,S,K),setOf(W,E),floor=true),
        add("march","Marcha suave en el lugar",DayType.CARDIO,"Cardio de piernas",L,setOf(B),steps="Marcha a un ritmo cómodo, sin impacto."),
        add("stepup","Subida a plataforma baja",DayType.CARDIO,"Cardio de piernas",L,setOf(B),intensity=2),
        add("lowjack","Aperturas sin salto",DayType.CARDIO,"Cardio mixto",U+L,setOf(B),steps="Da pasos laterales y abre los brazos suavemente."),
        add("stepjack","Pasos laterales controlados",DayType.CARDIO,"Cardio de piernas",L,setOf(B)),
        add("shadowbox","Boxeo suave sentado sin cargas",DayType.CARDIO,"Cardio de brazos",U,setOf(H),seated=true,steps="Sentado en superficie estable, alterna movimientos cortos de brazos sin impacto."),
        add("seatedarm379","Alternancia de brazos sentado",DayType.CARDIO,"Cardio de brazos",U,setOf(H),seated=true,steps="Sentado, alterna movimientos pequeños de brazos, respirando con naturalidad."),
        add("seatedmarch","Marcha sentada",DayType.CARDIO,"Cardio de piernas",L,setOf(B),seated=true),
        add("breathing","Respiración suave",DayType.MOBILITY,"Respiración",emptySet(),seated=true,steps="Respira con naturalidad y sin contener el aire."),
        add("ankle","Movilidad de tobillo",DayType.MOBILITY,"Tobillo",setOf(A),setOf(K,H),seated=true),
        add("wrist","Movilidad de muñeca",DayType.MOBILITY,"Muñeca",setOf(W),seated=true),
        add("shoulder","Movilidad de hombro",DayType.MOBILITY,"Hombro",setOf(S),seated=true),
        add("neck","Movilidad de cuello",DayType.MOBILITY,"Cuello",setOf(N),seated=true),
        add("hipcircle","Movilidad de cadera",DayType.MOBILITY,"Cadera",setOf(H),setOf(B,K,A)),
        add("catcow","Movilidad de columna",DayType.MOBILITY,"Columna",setOf(B),setOf(K,W,S),floor=true),
        add("elbowmob","Flexión y extensión de codo",DayType.MOBILITY,"Codo",setOf(E),seated=true),
        add("forearmmob","Rotación del antebrazo",DayType.MOBILITY,"Antebrazo",setOf(E,W),seated=true)
    )
}
