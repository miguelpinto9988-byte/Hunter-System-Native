package com.huntersystem.nativeapp.domain

/** Pure Kotlin models: no Android APIs, JavaScript, or WebView. */
enum class DayType(val label: String) { FORCE("Fuerza"), CARDIO("Cardio"), MOBILITY("Movilidad"), REST("Descanso") }
enum class Zone(val label: String) {
    NECK("Cuello"), SHOULDER("Hombro"), ELBOW("Codo"), WRIST("Muñeca / mano"),
    BACK("Espalda"), HIP("Cadera"), KNEE("Rodilla"), ANKLE("Tobillo / pie")
}
enum class Risk(val label: String) {
    NONE("Sin molestias"), MILD("Molestia leve"), MODERATE("Molestia moderada"),
    SEVERE("Dolor fuerte"), ACUTE("Lesión reciente"), SURGERY("Cirugía o fractura"), UNKNOWN("Sin valorar")
}
enum class Level { BASICO, INTERMEDIO, AVANZADO }
enum class ShadowAvatar(val label: String) { IGRIS("Igris"), IRON("Iron"), TANK("Tank"), BERU("Beru"), DOKJA("Dokja Kim") }

data class Profile(
    val name: String = "Cazador", val age: Int = 18, val heightCm: Int = 170,
    val weightKg: Int = 70, val gender: String = "Prefiero no indicar",
    val goals: String = "Condición física general", val level: Level = Level.BASICO,
    val companion: ShadowAvatar = ShadowAvatar.IGRIS,
    val equipment: Set<String> = emptySet(),
    val injuryZones: Set<Zone> = emptySet(), val risk: Risk = Risk.NONE,
    val activityCleared: Boolean = false,
    /** Monday starting the three-week native programme; blank on first run. */
    val cycleStartIso: String = "",
    val restrictions: Set<String> = emptySet(),
    val schedule: List<DayType> = listOf(DayType.FORCE,DayType.CARDIO,DayType.MOBILITY,DayType.FORCE,DayType.CARDIO,DayType.MOBILITY,DayType.REST)
)

data class Exercise(
    val id: String, val name: String, val category: DayType, val group: String,
    /** Involved joints, plus joints loaded for balance/support. */
    val involved: Set<Zone>, val supports: Set<Zone> = emptySet(),
    val required: Set<String> = emptySet(), val intensity: Int = 1,
    val impact: Boolean = false, val seated: Boolean = false, val floor: Boolean = false,
    val overhead: Boolean = false, val steps: String = "",
    val motionId: String? = null, val seconds: Int = 0
)

data class Prescription(val exercise: Exercise, val sets: Int, val target: Int, val restSeconds: Int)
enum class PlanStatus { READY, REST, REQUIRES_REVIEW, NO_COMPATIBLE }
data class DailyPlan(val type: DayType, val status: PlanStatus, val items: List<Prescription>, val message: String)
/** Original repetition/load details are retained for existing completed records during V38 import. */
data class SetRecord(val done:Boolean=false,val value:Double=0.0,val kg:Double=0.0)
data class SessionLog(
    val finished: Set<String> = emptySet(), val effort: Int = 0,
    val pain: Boolean = false, val fatigue: Boolean = false,
    val note:String = "", val sets:Map<String,List<SetRecord>> = emptyMap(),
    val completed:Boolean = false
)
