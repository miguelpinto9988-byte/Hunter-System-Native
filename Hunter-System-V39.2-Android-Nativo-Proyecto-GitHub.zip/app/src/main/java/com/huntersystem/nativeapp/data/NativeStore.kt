package com.huntersystem.nativeapp.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.huntersystem.nativeapp.domain.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.hunterDataStore by preferencesDataStore("hunter_native_v39")

/** Native DataStore storage; profiles are saved atomically as one document. */
class NativeStore(private val context: Context) {
    private val profileKey=stringPreferencesKey("profile_v1")
    private val logsKey=stringPreferencesKey("logs_v1")
    val profile: Flow<Profile> = context.hunterDataStore.data.map { prefs ->
        runCatching { decodeProfile(prefs[profileKey] ?: "{}") }.getOrDefault(Profile())
    }
    val logs: Flow<Map<String,SessionLog>> = context.hunterDataStore.data.map { prefs ->
        runCatching { decodeLogs(prefs[logsKey] ?: "{}") }.getOrDefault(emptyMap())
    }
    suspend fun exportNative():String {
        val prefs=context.hunterDataStore.data.first()
        return JSONObject().apply {
            put("format","hunter-native-v39");put("version",1)
            put("profile",JSONObject(prefs[profileKey]?:"{}"))
            put("logs",JSONObject(prefs[logsKey]?:"{}"))
        }.toString(2)
    }
    suspend fun importLegacy(candidate:MigrationPreview) {
        context.hunterDataStore.edit { prefs ->
            prefs[profileKey]=encodeProfile(withCycleStart(candidate.profile)).toString()
            prefs[logsKey]=encodeLogs(candidate.logs).toString()
        }
    }
    suspend fun saveProfile(p:Profile) { context.hunterDataStore.edit { it[profileKey]=encodeProfile(withCycleStart(p)).toString() } }
    private fun withCycleStart(p: Profile): Profile = if (p.cycleStartIso.isNotBlank()) p else
        p.copy(cycleStartIso=java.time.LocalDate.now().with(java.time.DayOfWeek.MONDAY).toString())
    suspend fun toggleDone(day:String,id:String) {
        context.hunterDataStore.edit { prefs ->
            val old=runCatching { decodeLogs(prefs[logsKey] ?: "{}") }.getOrDefault(emptyMap()).toMutableMap()
            val current=old[day]?:SessionLog()
            val done=current.finished.toMutableSet()
            if(!done.add(id))done.remove(id)
            old[day]=current.copy(finished=done)
            prefs[logsKey]=encodeLogs(old).toString()
        }
    }
    suspend fun recordFeedback(day:String,effort:Int,pain:Boolean,fatigue:Boolean,note:String="") {
        context.hunterDataStore.edit {prefs ->
            val old=runCatching {decodeLogs(prefs[logsKey]?:"{}")}.getOrDefault(emptyMap()).toMutableMap()
            old[day]=(old[day]?:SessionLog()).copy(effort=effort.coerceIn(0,10),pain=pain,fatigue=fatigue,note=note.take(500))
            prefs[logsKey]=encodeLogs(old).toString()
        }
    }
}

private fun JSONObject.strings(name:String):Set<String> {
    val arr=optJSONArray(name)?:return emptySet()
    return (0 until arr.length()).mapNotNull{arr.optString(it).takeIf(String::isNotBlank)}.toSet()
}
private fun JSONObject.dayTypes():List<DayType> {
    val arr=optJSONArray("schedule")?:return Profile().schedule
    val days=(0 until arr.length()).map{runCatching{DayType.valueOf(arr.getString(it))}.getOrDefault(DayType.REST)}
    return if(days.size==7)days else Profile().schedule
}
private fun JSONObject.enumRisk():Risk=runCatching{Risk.valueOf(optString("risk","NONE"))}.getOrDefault(Risk.UNKNOWN)
private fun <T:Enum<T>> named(value:String,default:T,all:Array<T>):T=all.firstOrNull{it.name==value}?:default
fun decodeProfile(raw:String):Profile {
    val j=JSONObject(raw);val default=Profile()
    return Profile(
        name=j.optString("name",default.name).take(80),age=j.optInt("age",default.age).coerceIn(0,120),
        heightCm=j.optInt("heightCm",default.heightCm).coerceIn(0,260),
        weightKg=j.optInt("weightKg",default.weightKg).coerceIn(0,500),
        gender=j.optString("gender",default.gender),goals=j.optString("goals",default.goals),
        level=named(j.optString("level"),default.level,Level.entries.toTypedArray()),
        companion=named(j.optString("companion"),default.companion,ShadowAvatar.entries.toTypedArray()),
        equipment=j.strings("equipment"),injuryZones=j.strings("injuryZones").mapNotNull {rawZone->Zone.entries.firstOrNull {it.name==rawZone}}.toSet(),
        risk=j.enumRisk(),activityCleared=j.optBoolean("activityCleared",false),
        cycleStartIso=j.optString("cycleStartIso", ""),restrictions=j.strings("restrictions"),schedule=j.dayTypes()
    )
}
fun encodeProfile(p:Profile):JSONObject=JSONObject().apply {
    put("version",1);put("name",p.name);put("age",p.age);put("heightCm",p.heightCm);put("weightKg",p.weightKg)
    put("gender",p.gender);put("goals",p.goals);put("level",p.level.name);put("companion",p.companion.name)
    put("equipment",JSONArray(p.equipment.toList()));put("injuryZones",JSONArray(p.injuryZones.map{it.name}))
    put("risk",p.risk.name);put("activityCleared",p.activityCleared);put("cycleStartIso",p.cycleStartIso);put("restrictions",JSONArray(p.restrictions.toList()))
    put("schedule",JSONArray(p.schedule.map{it.name}))
}
fun decodeLogs(raw:String):Map<String,SessionLog> {
    val obj=JSONObject(raw)
    return obj.keys().asSequence().associateWith {day ->
        val v=obj.getJSONObject(day)
        val details=v.optJSONObject("sets")?:JSONObject()
        val saved=buildMap<String,List<SetRecord>> {
            val keys=details.keys()
            while(keys.hasNext()) {
                val id=keys.next()
                val entries=details.optJSONArray(id)?:continue
                put(id,(0 until minOf(entries.length(),20)).mapNotNull { i ->
                    val a=entries.optJSONObject(i)?:return@mapNotNull null
                    SetRecord(a.optBoolean("done",false), a.optDouble("value",0.0).takeIf(Double::isFinite)?:0.0,
                        a.optDouble("kg",0.0).takeIf(Double::isFinite)?:0.0)
                })
            }
        }
        SessionLog(v.strings("finished"),v.optInt("effort",0),v.optBoolean("pain",false),v.optBoolean("fatigue",false),
            v.optString("note", "").take(500),saved,v.optBoolean("completed",false))
    }
}
fun encodeLogs(logs:Map<String,SessionLog>):JSONObject=JSONObject().apply {
    logs.forEach { (key,value)->put(key,JSONObject().apply {
        put("finished",JSONArray(value.finished.toList()))
        put("effort",value.effort);put("pain",value.pain);put("fatigue",value.fatigue)
        put("note",value.note.take(500));put("completed",value.completed)
        put("sets",JSONObject().also{ details -> value.sets.forEach { (id,records) ->
            details.put(id,JSONArray(records.map { row -> JSONObject().apply {
                put("done",row.done);put("value",row.value);put("kg",row.kg)
            } }))
        } })
    }) }
}
