package com.huntersystem.nativeapp.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.huntersystem.nativeapp.data.*
import com.huntersystem.nativeapp.domain.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Locale

private val navigation=listOf("Panel","Misiones","Rutinas","Ejercicios","Progreso","Perfil")
private val weekday=listOf("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo")

@Composable fun HunterApp(store:NativeStore) {
    val profile by store.profile.collectAsState(initial=Profile())
    val logs by store.logs.collectAsState(initial=emptyMap())
    var page by remember {mutableIntStateOf(0)}
    var selectedDay by remember {mutableStateOf<LocalDate?>(null)}
    var selectedMotion by remember {mutableStateOf<MotionMeta?>(null)}
    val context=androidx.compose.ui.platform.LocalContext.current
    val motionsRepo=remember{ MotionRepository(context.applicationContext) }
    var motionIndex by remember {mutableStateOf<List<MotionMeta>>(emptyList())}
    LaunchedEffect(Unit) {motionIndex=runCatching{motionsRepo.index()}.getOrDefault(emptyList())}
    val scope=rememberCoroutineScope()
    val notice=remember {SnackbarHostState()}
    var legacyPreview by remember {mutableStateOf<MigrationPreview?>(null)}
    val exportFile=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) {uri ->
        if(uri!=null)scope.launch {
            try {
                val backup=store.exportNative()
                withContext(Dispatchers.IO){context.contentResolver.openOutputStream(uri)?.use{it.write(backup.toByteArray(Charsets.UTF_8))}
                    ?:error("No se pudo escribir el archivo")}
                notice.showSnackbar("Copia nativa exportada correctamente")
            }catch(exc:Exception){notice.showSnackbar("Exportación fallida: ${exc.message}")}
        }
    }
    val importFile=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri ->
        if(uri!=null)scope.launch {
            runCatching {withContext(Dispatchers.IO){
                val bytes=context.contentResolver.openInputStream(uri)?.use{it.readBytes()}?:error("Archivo no disponible")
                require(bytes.size<=5_000_000){"La copia supera los 5 MB"}
                LegacyMigration.inspect(bytes.toString(Charsets.UTF_8))
            }}.onSuccess{legacyPreview=it}.onFailure{notice.showSnackbar("Error al leer copia: ${it.message}")}
        }
    }
    val today=LocalDate.now()
    HunterTheme {
        Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Column {Text("HUNTER SYSTEM",fontSize=21.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,color=WHITE)
                    Text("NATIVO · ${profile.companion.label.uppercase()}",fontSize=10.sp,letterSpacing=1.sp,color=CYAN)}
                Text("RANGO ${rank(logs.values.sumOf{it.finished.size})}",fontSize=12.sp,color=CYAN)
            }
            BoxWithConstraints(Modifier.weight(1f)) {
                val wide=maxWidth>=700.dp
                Row {
                    if(wide)Column(Modifier.width(170.dp).fillMaxHeight().padding(8.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        navigation.forEachIndexed {i,t ->NavigationItem(t,i==page) {page=i} }
                    }
                    Box(Modifier.weight(1f)) {
                        AnimatedContent(targetState=page,transitionSpec={androidx.compose.animation.fadeIn(tween(180)) togetherWith androidx.compose.animation.fadeOut(tween(140))},label="native-navigation") { screen ->
                            when(screen) {
                                0->PanelScreen(profile,today,logs,onMission={selectedDay=today},onNavigate={page=it})
                                1->MissionsScreen(profile,logs,onSelect={selectedDay=it})
                                2->RoutinesScreen(profile,logs,onSelect={selectedDay=it})
                                3->ExercisesScreen(motionIndex,onSelect={selectedMotion=it})
                                4->ProgressScreen(profile,logs)
                                else->ProfileScreen(profile,onExport={exportFile.launch("hunter-native-v39.json")},onImport={importFile.launch(arrayOf("application/json","text/plain","*/*"))},onSave={newProfile->scope.launch{
                                    store.saveProfile(newProfile)
                                    notice.showSnackbar("Configuración guardada. Calendario, objetivos, restricciones y acompañante actualizados.")
                                }})
                            }
                        }
                    }
                }
                if(!wide) { /* Mobile navigation is outside this responsive content box. */ }
            }
            // Bottom navigation only on narrow widths, detected from the current screen width.
            BoxWithConstraints {
                if(maxWidth<700.dp) Row(Modifier.fillMaxWidth().background(Color(0xFF0D192A)).height(62.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                    navigation.forEachIndexed {i,t -> Column(Modifier.weight(1f).clickable{page=i},horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(listOf("⌂","▦","▤","◇","▥","♙")[i],color=if(page==i)CYAN else MUTED,fontSize=20.sp)
                        Text(t,color=if(page==i)CYAN else MUTED,fontSize=9.sp,maxLines=1)
                    }}
                }
            }
        }
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.BottomCenter) {SnackbarHost(notice)}
        legacyPreview?.let {candidate ->
            AlertDialog(onDismissRequest={legacyPreview=null},title={Text("Importar copia: ${candidate.origin}")},text={
                Column {Text("Perfil: ${candidate.profile.name} · Días registrados: ${candidate.logs.size}")
                    candidate.warnings.forEach{Text("• $it",fontSize=12.sp,color=MUTED)}
                    Text("Esta operación reemplazará tu perfil y registros nativos actuales. La copia original no será modificada.",color=Color(0xFFFFD9A8))
                }
            },confirmButton={TextButton(onClick={scope.launch {store.importLegacy(candidate);legacyPreview=null;notice.showSnackbar("Copia importada. Revisa el perfil y los ejercicios adaptados.")}}){Text("Confirmar importación")}},
              dismissButton={TextButton(onClick={legacyPreview=null}){Text("Cancelar")}})
        }
        selectedDay?.let {date->
            val day=date.dayOfWeek.value-1
            val week=TrainingCalendar.weekIndex(profile,date)
            val dateKey=date.toString()
            val plan=Planner.plan(profile,day,week,logs[dateKey]?:SessionLog(),
                recent=TrainingCalendar.recent(logs,date))
            Dialog(onDismissRequest={selectedDay=null},properties=DialogProperties(usePlatformDefaultWidth=false)) {
                BoxWithConstraints(Modifier.fillMaxWidth(.96f)) {
                    HunterPanel(Modifier.widthIn(max=720.dp).heightIn(max=maxHeight*.92f).verticalScroll(rememberScrollState())) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            HunterTitle("MISIÓN DIARIA",dateKey)
                            TextButton(onClick={selectedDay=null}){Text("✕  Cerrar")}
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(plan.type.label,fontSize=21.sp,color=CYAN,fontWeight=FontWeight.Bold)
                        Text(plan.message,color=MUTED)
                        Spacer(Modifier.height(12.dp))
                        when(plan.status) {
                            PlanStatus.READY->{
                                val completed=plan.items.count{it.exercise.id in (logs[dateKey]?.finished?:emptySet())}
                                Text("$completed / ${plan.items.size} objetivos completados",color=WHITE)
                                LinearProgressIndicator(progress={completed.toFloat()/plan.items.size},modifier=Modifier.fillMaxWidth())
                                Spacer(Modifier.height(10.dp))
                                plan.items.forEach {task ->
                                    Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(BG, RoundedCornerShape(9.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                                        Checkbox(checked=task.exercise.id in (logs[dateKey]?.finished?:emptySet()),onCheckedChange={scope.launch{store.toggleDone(dateKey,task.exercise.id)}})
                                        Column(Modifier.weight(1f)) {
                                            Text(task.exercise.name,fontWeight=FontWeight.Bold)
                                            Text("${task.sets} series · ${task.target} ${if(task.exercise.category==DayType.CARDIO)"segundos" else "repeticiones"} · ${task.restSeconds}s descanso",fontSize=11.sp,color=MUTED)
                                        }
                                        TextButton(onClick={selectedMotion=motionIndex.firstOrNull{it.id==task.exercise.motionId}}){Text("Ver")}
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                var effort by remember(dateKey) {mutableIntStateOf(logs[dateKey]?.effort?:0)}
                                var pain by remember(dateKey) {mutableStateOf(logs[dateKey]?.pain?:false)}
                                var fatigue by remember(dateKey) {mutableStateOf(logs[dateKey]?.fatigue?:false)}
                                var sessionNote by remember(dateKey) {mutableStateOf(logs[dateKey]?.note?:"")}
                                Text("Esfuerzo percibido $effort / 10",color=CYAN)
                                Slider(value=effort.toFloat(),onValueChange={effort=it.toInt()},valueRange=0f..10f,steps=9)
                                Row(verticalAlignment=Alignment.CenterVertically){Checkbox(pain,{pain=it});Text("Molestia");Spacer(Modifier.width(8.dp));Checkbox(fatigue,{fatigue=it});Text("Fatiga")}
                                OutlinedTextField(sessionNote,{sessionNote=it.take(500)},label={Text("Notas de la sesión")},
                                    minLines=2,modifier=Modifier.fillMaxWidth())
                                Button(onClick={scope.launch{store.recordFeedback(dateKey,effort,pain,fatigue,sessionNote)}}){Text("Guardar registro")}
                            }
                            PlanStatus.REST -> Text("Tu descanso se mantiene tal como fue programado.")
                            else -> Text("No se generaron ejercicios automáticos para este caso. El día elegido no se ha cambiado a descanso.",color=Color(0xFFFAD9A0))
                        }
                    }
                }
            }
        }
        selectedMotion?.let {meta ->
            var motion by remember(meta.id){mutableStateOf<Motion?>(null)}
            var motionLoaded by remember(meta.id){mutableStateOf(false)}
            LaunchedEffect(meta.id){
                motionLoaded=false
                motion=motionsRepo.motion(meta)
                motionLoaded=true
            }
            Dialog(onDismissRequest={selectedMotion=null},properties=DialogProperties(usePlatformDefaultWidth=false)) {
                BoxWithConstraints(Modifier.fillMaxWidth(.95f)) {
                    HunterPanel(Modifier.widthIn(max=680.dp).heightIn(max=maxHeight*.88f).verticalScroll(rememberScrollState())) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                            Text(meta.name,fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                            TextButton(onClick={selectedMotion=null}){Text("✕")}
                        }
                        Text("Animación vectorial nativa · modelo original sin revisión biomecánica individual",color=MUTED,fontSize=11.sp)
                        if(!motionLoaded)CircularProgressIndicator()
                        else if(motion==null)Text("No se pudo cargar esta demostración vectorial.",color=MUTED)
                        else NativeMotionView(motion!!)
                    }
                }
            }
        }
    }
}

private fun rank(done:Int):String=when {done>=280->"S";done>=150->"A";done>=80->"B";done>=40->"C";done>=15->"D";else->"E"}

@Composable private fun NavigationItem(label:String,selected:Boolean,click:()->Unit){
    OutlinedButton(onClick=click,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(selected)PANEL else BG)) {
        Text(label,color=if(selected)CYAN else MUTED)
    }
}
@Composable private fun PanelScreen(p:Profile,today:LocalDate,logs:Map<String,SessionLog>,onMission:()->Unit,onNavigate:(Int)->Unit) {
    val plan=Planner.plan(p,today.dayOfWeek.value-1,TrainingCalendar.weekIndex(p,today),
        logs[today.toString()]?:SessionLog(),recent=TrainingCalendar.recent(logs,today))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        HunterTitle("PORTAL DEL SISTEMA","Panel del cazador · ${p.name}")
        HunterPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                AnimatedAvatar(p.companion,Modifier.width(112.dp).height(155.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.companion.label,fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("Acompañante activo",color=MUTED)
                    Text("Objetivos: ${p.goals}",color=WHITE,maxLines=3,overflow=TextOverflow.Ellipsis)
                }
            }
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("MISIÓN DE HOY",color=CYAN,letterSpacing=2.sp)
            Text(plan.type.label,fontSize=26.sp,fontWeight=FontWeight.Bold)
            Text(plan.message,color=MUTED)
            if(plan.status==PlanStatus.READY)Text("${plan.items.size} ejercicios disponibles",color=WHITE)
            Spacer(Modifier.height(12.dp));Button(onClick=onMission,modifier=Modifier.fillMaxWidth()) {Text("ABRIR MISIÓN")}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick={onNavigate(2)},modifier=Modifier.weight(1f)){Text("Rutinas")}
            OutlinedButton(onClick={onNavigate(4)},modifier=Modifier.weight(1f)){Text("Progreso")}
        }
    }
}
@Composable private fun MissionsScreen(p:Profile,logs:Map<String,SessionLog>,onSelect:(LocalDate)->Unit) {
    val start=LocalDate.now().with(java.time.DayOfWeek.MONDAY)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        HunterTitle("MISIONES","Semana actual · fuerza · cardio · movilidad · descanso")
        (0..6).forEach {i ->
            val date=start.plusDays(i.toLong());val plan=Planner.plan(p,i,TrainingCalendar.weekIndex(p,date),
                logs[date.toString()]?:SessionLog(),recent=TrainingCalendar.recent(logs,date))
            HunterPanel(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${weekday[i]} — ${plan.type.label}",fontWeight=FontWeight.Bold)
                        Text(if(plan.status==PlanStatus.READY) "${plan.items.count{it.exercise.id in (logs[date.toString()]?.finished?:emptySet())}} / ${plan.items.size} completados" else plan.message,fontSize=12.sp,color=MUTED)
                    }
                    TextButton(onClick={onSelect(date)}){Text("Abrir  →")}
                }
            }
        }
    }
}
@Composable private fun RoutinesScreen(p:Profile,logs:Map<String,SessionLog>,onSelect:(LocalDate)->Unit) {
    val start=LocalDate.now().with(java.time.DayOfWeek.MONDAY)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        HunterTitle("RUTINAS","Plan progresivo de tres semanas (adaptación conservadora)")
        repeat(3){w ->
            Text("SEMANA ${TrainingCalendar.weekIndex(p,start.plusDays(w*7L))+1} DEL CICLO",fontSize=19.sp,color=CYAN,fontWeight=FontWeight.Bold)
            repeat(7){i ->
                val date=start.plusDays((w*7+i).toLong())
                val plan=Planner.plan(p,i,TrainingCalendar.weekIndex(p,date),
                    logs[date.toString()]?:SessionLog(),recent=TrainingCalendar.recent(logs,date))
                OutlinedButton(onClick={onSelect(date)},modifier=Modifier.fillMaxWidth()) {
                    Text("${weekday[i]} · ${plan.type.label}  —  ${if(plan.status==PlanStatus.READY)"${plan.items.size} ejercicios" else if(plan.status==PlanStatus.REST)"Descanso" else "Revisión necesaria"}",maxLines=2)
                }
            }
        }
    }
}
@Composable private fun ExercisesScreen(index:List<MotionMeta>,onSelect:(MotionMeta)->Unit) {
    var filter by remember {mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HunterTitle("EJERCICIOS","${index.size} animaciones originales importadas al motor nativo")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value=filter,onValueChange={filter=it},label={Text("Buscar ejercicio")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Text("Solo ${ExerciseCatalog.exercises.size} ejercicios tienen metadatos para planificación; los demás son demostraciones visuales.",fontSize=12.sp,color=MUTED)
        val visible=remember(index,filter){index.filter { it.name.contains(filter,true)||it.id.contains(filter,true) }.toList()}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
            items(visible,key={it.id}) {item ->
                Row(Modifier.fillMaxWidth().clickable {onSelect(item)}.background(PANEL, RoundedCornerShape(10.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(item.name,modifier=Modifier.weight(1f),maxLines=2)
                    Text("${item.durationMs/1000f}s  ▶",color=CYAN)
                }
            }
        }
    }
}
@Composable private fun ProgressScreen(p:Profile,logs:Map<String,SessionLog>) {
    val tasks=logs.values.sumOf{it.finished.size}
    val reviewed=logs.values.count{it.effort>0}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        HunterTitle("PROGRESO","Historial local · sin sincronización obligatoria")
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("RANGO ${rank(tasks)}",fontSize=34.sp,fontWeight=FontWeight.Black,color=CYAN)
            Text("${tasks*25} XP · $tasks objetivos marcados",color=WHITE)
            Text("$reviewed días con esfuerzo registrado",color=MUTED)
            LinearProgressIndicator(progress={(tasks%15)/15f},modifier=Modifier.fillMaxWidth())
        }
        logs.entries.sortedByDescending {it.key}.take(35).forEach { (date,log) ->
            HunterPanel(Modifier.fillMaxWidth()) {
                Text(date,fontWeight=FontWeight.Bold)
                Text("Ejercicios completados: ${log.finished.size} · esfuerzo: ${log.effort}/10",color=MUTED)
                if(log.pain||log.fatigue)Text("Registro de molestias o fatiga · el plan siguiente será conservador",color=Color(0xFFFFD5A8))
                if(log.note.isNotBlank())Text("Notas: ${log.note}",color=MUTED)
                if(log.sets.isNotEmpty())Text("Series registradas: ${log.sets.values.sumOf { it.size }}",color=MUTED)
            }
        }
    }
}
