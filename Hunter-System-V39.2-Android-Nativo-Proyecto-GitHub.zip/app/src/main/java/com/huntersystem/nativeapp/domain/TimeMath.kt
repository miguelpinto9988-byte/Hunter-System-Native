package com.huntersystem.nativeapp.domain

/** Elapsed-time animation, independent of the number of drawn frames. */
object TimeMath {
    fun phase(elapsedNanos:Long, durationMillis:Long, speed:Float=1f):Float {
        require(durationMillis>0)
        val wholeMs=(elapsedNanos.coerceAtLeast(0L).toDouble()/1_000_000.0)*speed.coerceAtLeast(.01f)
        val cycle=wholeMs%durationMillis
        return (cycle/durationMillis).toFloat().coerceIn(0f,1f)
    }
    /** Continue a paused animation at a new speed without resetting its position. */
    fun continuedPhase(previous:Float,elapsedNanos:Long,durationMillis:Long,speed:Float=1f):Float {
        val shift=phase(elapsedNanos,durationMillis,speed)
        val raw=(previous.coerceIn(0f,1f).toDouble()+shift.toDouble())%1.0
        return raw.toFloat()
    }
}
