package com.huntersystem.nativeapp.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.huntersystem.nativeapp.domain.*

private val weekdayNames=listOf("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo")
private val restrictionsMap=linkedMapOf(
    "sin-impacto" to "Sin saltos / impactos", "sin-suelo" to "Evitar el suelo",
    "solo-sentado" to "Solo sentado", "sin-elevacion" to "Sin brazos elevados",
    "sin-cargas" to "Sin carga externa", "sin-manos" to "Sin apoyo en manos",
    "sin-flexion-rodilla" to "Sin flexión repetida de rodilla", "sin-columna" to "Sin flexión o giro de columna"
)
@Composable fun ProfileScreen(profile:Profile,onExport:()->Unit,onImport:()->Unit,onSave:(Profile)->Unit) {
    var draft by remember(profile){mutableStateOf(profile)}
    var age by remember(profile){mutableStateOf(profile.age.toString())}
    var weight by remember(profile){mutableStateOf(profile.weightKg.toString())}
    var height by remember(profile){mutableStateOf(profile.heightCm.toString())}
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        HunterTitle("PERFIL DEL CAZADOR","Una única acción para guardar e interpretar todos los cambios")
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick=onImport,modifier=Modifier.weight(1f)) {Text("Importar copia")}
            OutlinedButton(onClick=onExport,modifier=Modifier.weight(1f)) {Text("Exportar copia")}
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("IDENTIDAD",color=CYAN,fontWeight=FontWeight.Bold)
            OutlinedTextField(draft.name,{draft=draft.copy(name=it)},label={Text("Nombre")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(draft.gender,{draft=draft.copy(gender=it)},label={Text("Género (opcional)")},modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(age,{age=it.filter(Char::isDigit).take(3)},label={Text("Edad")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(weight,{weight=it.filter(Char::isDigit).take(3)},label={Text("Peso kg")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(height,{height=it.filter(Char::isDigit).take(3)},label={Text("Talla cm")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            }
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("OBJETIVOS Y NIVEL",color=CYAN,fontWeight=FontWeight.Bold)
            OutlinedTextField(draft.goals,{draft=draft.copy(goals=it)},label={Text("Describe tus objetivos")},minLines=2,modifier=Modifier.fillMaxWidth())
            Text("Interpretación local: ${GoalInterpreter.parse(draft.goals).joinToString {it.name.lowercase()}}",color=MUTED)
            Level.entries.forEach {level ->
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.clickable{draft=draft.copy(level=level)}) {
                    RadioButton(draft.level==level,onClick={draft=draft.copy(level=level)})
                    Text(level.name.lowercase().replaceFirstChar(Char::uppercase))
                }
            }
            Text("Equipo",color=MUTED)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Checkbox("db" in draft.equipment,{selected->draft=draft.copy(equipment=if(selected)draft.equipment+"db" else draft.equipment-"db")})
                Text("Mancuernas")
            }
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("ACOMPAÑANTE",color=CYAN,fontWeight=FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                ShadowAvatar.entries.forEach {av ->
                    FilterChip(selected=draft.companion==av,onClick={draft=draft.copy(companion=av)},label={Text(av.label)})
                }
            }
            Text("La selección se aplicará en el panel principal después de guardar.",color=MUTED)
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("DÍAS DE ENTRENAMIENTO",color=CYAN,fontWeight=FontWeight.Bold)
            Text("Elige Fuerza, Cardio, Movilidad o Descanso para cada día.",color=MUTED)
            weekdayNames.forEachIndexed {index,label ->
                var open by remember {mutableStateOf(false)}
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(label,modifier=Modifier.weight(1f))
                    Box {
                        OutlinedButton(onClick={open=true}){Text("${draft.schedule[index].label}  ▾")}
                        DropdownMenu(expanded=open,onDismissRequest={open=false}) {
                            DayType.entries.forEach {type ->
                                DropdownMenuItem(text={Text(type.label)},onClick={
                                    draft=draft.copy(schedule=draft.schedule.toMutableList().also{it[index]=type});open=false
                                })
                            }
                        }
                    }
                }
            }
        }
        HunterPanel(Modifier.fillMaxWidth()) {
            Text("LESIONES Y MOLESTIAS",color=CYAN,fontWeight=FontWeight.Bold)
            Text("Las zonas indicadas se excluyen del motor automático de selección, incluidas las que sirven de apoyo.",fontSize=12.sp,color=MUTED)
            Zone.entries.forEach {zone ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(zone in draft.injuryZones,{selected-> draft=draft.copy(injuryZones=if(selected)draft.injuryZones+zone else draft.injuryZones-zone) })
                    Text(zone.label)
                }
            }
            Text("Estado actual",color=MUTED)
            Risk.entries.forEach {level ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(draft.risk==level,onClick={draft=draft.copy(risk=level)})
                    Text(level.label)
                }
            }
            Row(verticalAlignment=Alignment.CenterVertically) {
                Checkbox(draft.activityCleared,{draft=draft.copy(activityCleared=it)})
                Text("Tengo indicación individual de actividad física compatible",fontSize=12.sp)
            }
            Text("Restricciones",color=MUTED)
            restrictionsMap.forEach { (id,label) ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(id in draft.restrictions,{selected->draft=draft.copy(restrictions=if(selected)draft.restrictions+id else draft.restrictions-id)})
                    Text(label,fontSize=13.sp)
                }
            }
            Text("Las animaciones son educativas y no constituyen una valoración clínica.",color=Color(0xFFFFDB9B),fontSize=11.sp)
        }
        if(error.isNotBlank())Text(error,color=Color(0xFFFFA4A4))
        Button(onClick={
            val a=age.toIntOrNull();val h=height.toIntOrNull();val w=weight.toIntOrNull()
            if(a==null||a !in 13..100||h==null||h !in 90..250||w==null||w !in 20..400) {
                error="Revisa edad, estatura y peso: hay valores vacíos o fuera del intervalo esperado."
            }else {
                error="";onSave(draft.copy(age=a,heightCm=h,weightKg=w))
            }
        },modifier=Modifier.fillMaxWidth().height(56.dp)) {Text("GUARDADO DE PERFIL CREADO",fontWeight=FontWeight.Black)}
        Text("Esta acción guarda los datos, reinterpreta objetivos y actualiza la planificación futura. Los registros existentes se conservan.",color=MUTED,fontSize=12.sp)
    }
}
