package com.huntersystem.nativeapp

import android.os.Bundle
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.huntersystem.nativeapp.data.NativeStore
import com.huntersystem.nativeapp.ui.HunterApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window,false)
        requestHighRefreshRateIfAvailable()
        val store = NativeStore(applicationContext)
        setContent { HunterApp(store) }
    }

    @Suppress("DEPRECATION")
    private fun requestHighRefreshRateIfAvailable() {
        // Android can decline this request for thermals, battery saver or user settings.
        val currentDisplay: Display = windowManager.defaultDisplay
        val currentMode=currentDisplay.mode
        val candidates=currentDisplay.supportedModes.filter {
            it.physicalWidth==currentMode.physicalWidth &&
            it.physicalHeight==currentMode.physicalHeight && it.refreshRate>=89f
        }
        val preferred=candidates.maxByOrNull {it.refreshRate} ?: return
        window.attributes=window.attributes.apply {preferredDisplayModeId=preferred.modeId}
    }
}
