package com.huntersystem.nativeapp.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Shared calendar logic for dashboard, routines and mission detail. */
object TrainingCalendar {
    fun monday(date: LocalDate): LocalDate = date.with(DayOfWeek.MONDAY)

    /** Three-week cycle anchored when a profile is first saved. */
    fun weekIndex(profile: Profile, date: LocalDate, today: LocalDate = LocalDate.now()): Int {
        val start = runCatching { LocalDate.parse(profile.cycleStartIso) }.getOrNull()
            ?: monday(today)
        val weeks = ChronoUnit.WEEKS.between(monday(start), monday(date))
        return Math.floorMod(weeks, 3L).toInt()
    }

    /** Historical training load before the selected day; not the session being edited. */
    fun recent(logs: Map<String, SessionLog>, before: LocalDate, days: Long = 7L): List<SessionLog> {
        return logs.entries.mapNotNull { (date, log) ->
            val parsed = runCatching { LocalDate.parse(date) }.getOrNull() ?: return@mapNotNull null
            if(parsed.isBefore(before) && !parsed.isBefore(before.minusDays(days))) parsed to log else null
        }.sortedByDescending { it.first }.map { it.second }
    }
}
