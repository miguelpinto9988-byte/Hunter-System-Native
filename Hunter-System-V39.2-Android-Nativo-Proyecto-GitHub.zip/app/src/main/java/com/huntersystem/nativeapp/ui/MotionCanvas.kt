package com.huntersystem.nativeapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.withFrameNanos
import com.huntersystem.nativeapp.domain.TimeMath
import com.huntersystem.nativeapp.data.Motion
import kotlin.math.floor

private val skeletonLinks = listOf(0 to 1,1 to 2,1 to 3,3 to 4,1 to 5,5 to 6,2 to 7,7 to 8,2 to 9,9 to 10)
/** Native Canvas vector keyframes, interpolation by elapsed monotonic time. */
@Composable
fun NativeMotionView(motion:Motion,modifier:Modifier=Modifier) {
    var speed by remember { mutableFloatStateOf(1f) }
    var playing by remember { mutableStateOf(true) }
    var phase by remember(motion.meta.id) { mutableFloatStateOf(0f) }
    // A captured phase is held during pause and when switching playback speed.
    LaunchedEffect(motion.meta.id,speed,playing) {
        if(!playing) return@LaunchedEffect
        val basePhase=phase
        val start=withFrameNanos{it}
        while(true) {
            val now=withFrameNanos{it}
            phase=TimeMath.continuedPhase(basePhase,now-start,motion.meta.durationMs,speed)
        }
    }
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().heightIn(min=170.dp, max=265.dp).aspectRatio(1.55f)) {
            drawRoundRect(Color(0xFF0C1628),cornerRadius=androidx.compose.ui.geometry.CornerRadius(18.dp.toPx()))
            val n=motion.frames.size
            if(n==0)return@Canvas
            val index=phase*n
            val a=floor(index).toInt().coerceIn(0,n-1)
            val b=(a+1)%n
            val mix=index-floor(index)
            val from=motion.frames[a];val to=motion.frames[b]
            val pts=from.indices.map{i ->
                val target=to.getOrNull(i)?:from[i]
                val x=from[i].x+(target.x-from[i].x)*mix
                val y=from[i].y+(target.y-from[i].y)*mix
                Offset(x/700f*size.width,y/800f*size.height)
            }
            drawLine(Color(0xFF37546C),Offset(0f,size.height*.9f),Offset(size.width,size.height*.9f),2.dp.toPx())
            for((a,b) in skeletonLinks) if(a<pts.size&&b<pts.size)drawLine(
                Color(0xFF9ACBFF),pts[a],pts[b],strokeWidth=6.dp.toPx(),cap=StrokeCap.Round)
            for((i,p) in pts.withIndex()) drawCircle(if(i==0)Color(0xFFB1E7FF) else Color(0xFF70AEEC),
                if(i==0)11.dp.toPx() else 5.dp.toPx(),p)
        }
        Text("Ciclo original: ${motion.meta.durationMs/1000f} s · velocidad ${speed}×",color=Color(0xFFB9CDE7))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf(.5f,1f,1.5f).forEach { value ->
                OutlinedButton(onClick={speed=value}) {Text("${value}×")}
            }
            TextButton(onClick={playing=!playing}){Text(if(playing)"Pausar" else "Reproducir")}
        }
    }
}
