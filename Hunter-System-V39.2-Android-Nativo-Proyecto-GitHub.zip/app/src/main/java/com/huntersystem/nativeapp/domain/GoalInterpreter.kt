package com.huntersystem.nativeapp.domain

import java.text.Normalizer

/** Transparent local interpretation: updated on every full profile save. */
object GoalInterpreter {
    enum class Goal { ESTHETIC, STRENGTH, CARDIO, AGILITY, MOBILITY, GENERAL }
    fun parse(text:String):Set<Goal> {
        val s=Normalizer.normalize(text.lowercase(),Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"),"")
        val result=mutableSetOf<Goal>()
        if(Regex("estetic|muscul|hipertrof|definicion").containsMatchIn(s))result.add(Goal.ESTHETIC)
        if(Regex("fuerza|potencia|resistenc.*muscul").containsMatchIn(s))result.add(Goal.STRENGTH)
        if(Regex("cardio|resistenc.*aerob|correr|caminar").containsMatchIn(s))result.add(Goal.CARDIO)
        if(Regex("agil|velocidad|coordinacion|equilibrio").containsMatchIn(s))result.add(Goal.AGILITY)
        if(Regex("movilidad|flexibilidad|estiramiento").containsMatchIn(s))result.add(Goal.MOBILITY)
        return result.ifEmpty {setOf(Goal.GENERAL)}
    }
}
