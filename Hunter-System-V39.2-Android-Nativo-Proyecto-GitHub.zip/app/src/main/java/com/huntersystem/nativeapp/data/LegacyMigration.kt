package com.huntersystem.nativeapp.data

import com.huntersystem.nativeapp.domain.*
import org.json.JSONArray
import org.json.JSONObject

data class MigrationPreview(
    val profile:Profile,val logs:Map<String,SessionLog>,val warnings:List<String>,
    val origin:String="V38.0"
)

/** Explicit user-supplied V38 WebView JSON backup import. Never runs HTML/JavaScript. */
object LegacyMigration {
    private val zoneMap=mapOf("neck" to Zone.NECK,"shoulder" to Zone.SHOULDER,
        "elbow" to Zone.ELBOW,"wrist" to Zone.WRIST,"back" to Zone.BACK,
        "hip" to Zone.HIP,"knee" to Zone.KNEE,"ankle" to Zone.ANKLE)
    private val restrictMap=mapOf("noImpact" to "sin-impacto","noFloor" to "sin-suelo",
        "noOverhead" to "sin-elevacion","noKnee" to "sin-flexion-rodilla","noWrist" to "sin-manos",
        "noLoad" to "sin-cargas","seatedOnly" to "solo-sentado","noSpine" to "sin-columna")
    fun inspect(raw:String):MigrationPreview {
        require(raw.toByteArray(Charsets.UTF_8).size <= 5_000_000) {"El archivo supera 5 MB"}
        val j=JSONObject(raw)
        // Exported native backups have a distinct schema; verify before reading any fields.
        if(j.optString("format")=="hunter-native-v39") {
            require(j.optInt("version",-1)==1) {"Versión de respaldo nativo incompatible"}
            val rawProfile=j.optJSONObject("profile") ?: error("Falta el perfil en el respaldo nativo")
            val rawLogs=j.optJSONObject("logs") ?: error("Falta el historial en el respaldo nativo")
            return MigrationPreview(decodeProfile(rawProfile.toString()),decodeLogs(rawLogs.toString()),
                listOf("Respaldo nativo reconocido: se restaurarán los datos de perfil e historial almacenados."),
                origin="Nativo V39")
        }
        require(j.optInt("version",-1)==1 && j.has("logs") && j.has("cycles")){"No es un respaldo compatible de Hunter System"}
        val p=j.optJSONObject("profile")?:throw IllegalArgumentException("La copia no contiene perfil")
        val warnings=mutableListOf("Se conservarán las series, repeticiones, cargas, notas y esfuerzo presentes en los registros de V38; el cálculo del rango y de las misiones difiere del sistema anterior.")
        val week=p.optJSONArray("weekPlan")
        // V38 indexed days with Date.getDay(): 0=Sunday; native Compose uses 0=Monday.
        val schedule=if(week?.length()==7) (0 until 7).map {i->
            when(week.optString((i+1)%7).lowercase()) {"train","strength"->DayType.FORCE;"cardio"->DayType.CARDIO;"mobility","recovery"->DayType.MOBILITY;else->DayType.REST}
        } else {warnings.add("No se encontró un calendario semanal completo; se utiliza el predeterminado.");Profile().schedule}
        val injuries=p.optJSONArray("injuries")?:JSONArray()
        val zones=(0 until injuries.length()).mapNotNull{i->
            val zone=injuries.optJSONObject(i)?.optString("zone")?:return@mapNotNull null
            zoneMap[zone]
        }.toSet()
        val health=p.optJSONObject("health")?:JSONObject()
        val stage=(0 until injuries.length()).mapNotNull { injuries.optJSONObject(it)?.optString("type") }.toSet()
        val risk=when {
            "surgery" in stage||"bone" in stage -> Risk.SURGERY
            health.optBoolean("acute",false)->Risk.ACUTE
            health.optString("pain")=="strong"->Risk.SEVERE
            health.optString("pain")=="moderate"->Risk.MODERATE
            health.optString("pain")=="mild"||zones.isNotEmpty()->Risk.MILD
            else->Risk.NONE
        }
        val oldAvatar=p.optString("companionCharacter",p.optString("companion",""))
        val avatar=when(oldAvatar.lowercase()) {
            "igris","knight"->ShadowAvatar.IGRIS;"iron","warrior"->ShadowAvatar.IRON
            "tank","bear"->ShadowAvatar.TANK;"beru","insect"->ShadowAvatar.BERU
            "dokja","dokja kim","reader"->ShadowAvatar.DOKJA;else->ShadowAvatar.IGRIS
        }
        val oldRestrictions=p.optJSONObject("restrictions")?:JSONObject()
        val restrictions=restrictMap.filter { (key,_)->oldRestrictions.optBoolean(key,false) }.values.toSet()
        val goals=listOf("finalGoal","finalTarget","goalGroup","goal").map{p.optString(it)}.firstOrNull{it.isNotBlank()} ?: "Condición física general"
        val equip=when(p.optString("equipment")) {"db"->setOf("db");"gym"->setOf("gym","db");else->emptySet()}
        val profile=Profile(
            name=p.optString("name","Cazador").take(35),age=p.optInt("age",18),
            heightCm=p.optDouble("height",170.0).toInt(),weightKg=p.optDouble("weight",70.0).toInt(),
            gender=p.optString("gender","Prefiero no indicar"),goals=goals,
            level=if(p.optString("experience")=="regular")Level.INTERMEDIO else Level.BASICO,
            companion=avatar,equipment=equip,injuryZones=zones,risk=risk,
            activityCleared=health.optBoolean("approved",false)&&health.optBoolean("translated",false),
            restrictions=restrictions,schedule=schedule
        )
        val old=j.getJSONObject("logs")
        val logs=buildMap {
            val keys=old.keys()
            while(keys.hasNext()) {
                val key=keys.next()
                if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(key))continue
                val log=old.optJSONObject(key)?:continue
                val finished=mutableSetOf<String>()
                val sets=mutableMapOf<String,List<SetRecord>>()
                val items=log.optJSONArray("items")?:JSONArray()
                for(i in 0 until minOf(items.length(),96)) {
                    val x=items.optJSONObject(i)?:continue
                    val id=x.optString("id").take(80)
                    if(id.isBlank())continue
                    val actual=x.optJSONArray("actual")?:JSONArray()
                    val records=(0 until minOf(actual.length(),20)).mapNotNull { n ->
                        val row=actual.optJSONObject(n)?:return@mapNotNull null
                        SetRecord(row.optBoolean("done",false),row.optDouble("value",0.0).coerceIn(0.0,3600.0),
                            row.optDouble("kg",0.0).coerceIn(0.0,500.0))
                    }
                    if(records.isNotEmpty())sets[id]=records
                    if(records.isNotEmpty()&&records.all{it.done}||x.optString("missionState")=="completed"||x.optBoolean("selfReported",false)) finished.add(id)
                }
                put(key,SessionLog(finished,log.optInt("rpe",0).coerceIn(0,10),log.optBoolean("pain",false),
                    log.optBoolean("fatigue",false),log.optString("note", "").take(500),sets,log.optBoolean("complete",false)))
            }
        }
        warnings.add("V38 usa domingo como primer día de weekPlan; el calendario se convirtió a lunes primero.")
        warnings.add("No se importan automáticamente las fotos, las notificaciones ni todas las métricas del motor V38; conserva la copia original como respaldo.")
        return MigrationPreview(profile,logs,warnings)
    }
}
