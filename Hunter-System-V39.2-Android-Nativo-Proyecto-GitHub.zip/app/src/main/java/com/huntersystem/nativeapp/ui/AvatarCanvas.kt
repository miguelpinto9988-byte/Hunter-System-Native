package com.huntersystem.nativeapp.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.huntersystem.nativeapp.R
import com.huntersystem.nativeapp.domain.ShadowAvatar

/** Original transparent portraits extracted from user's V38 assets, drawn by native Compose (no WebView). */
@Composable
fun AnimatedAvatar(avatar:ShadowAvatar, modifier:Modifier=Modifier) {
    val transition=rememberInfiniteTransition(label="companion-idle")
    val bob by transition.animateFloat(
        initialValue=0f,targetValue=6f,
        animationSpec=infiniteRepeatable(tween(2200,easing=FastOutSlowInEasing),RepeatMode.Reverse),
        label="companion-bob"
    )
    val res=when(avatar) {
        ShadowAvatar.IGRIS -> R.drawable.hunter_companion_igris
        ShadowAvatar.IRON -> R.drawable.hunter_companion_iron
        ShadowAvatar.TANK -> R.drawable.hunter_companion_tank
        ShadowAvatar.BERU -> R.drawable.hunter_companion_beru
        ShadowAvatar.DOKJA -> R.drawable.hunter_companion_dokja
    }
    Image(painter=painterResource(res),contentDescription="Acompañante ${avatar.label}",
        modifier=modifier.graphicsLayer { translationY=bob },contentScale=ContentScale.Fit)
}
