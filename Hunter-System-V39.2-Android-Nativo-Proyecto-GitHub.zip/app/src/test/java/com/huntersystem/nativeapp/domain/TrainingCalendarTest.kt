package com.huntersystem.nativeapp.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class TrainingCalendarTest {
    @Test fun stableWeeks() {
        val profile = Profile(cycleStartIso="2026-10-12")
        assertEquals(0, TrainingCalendar.weekIndex(profile, LocalDate.parse("2026-10-12")))
        assertEquals(1, TrainingCalendar.weekIndex(profile, LocalDate.parse("2026-10-19")))
        assertEquals(2, TrainingCalendar.weekIndex(profile, LocalDate.parse("2026-10-26")))
        assertEquals(0, TrainingCalendar.weekIndex(profile, LocalDate.parse("2026-11-02")))
    }
    @Test fun noWrongDayShift() {
        val p=Profile(schedule=listOf(DayType.FORCE, DayType.CARDIO, DayType.FORCE,
            DayType.MOBILITY, DayType.FORCE, DayType.CARDIO, DayType.REST))
        assertEquals(DayType.REST, Planner.plan(p,6).type)
        assertEquals(DayType.FORCE, Planner.plan(p,0).type)
    }
    @Test fun recentLoad() {
        val p=Profile()
        val past=listOf(SessionLog(fatigue=true))
        assertTrue(Planner.plan(p,0,2,recent=past).items.all {it.sets==1})
        assertTrue(Planner.plan(p,0,0).items.all {it.sets==2})
    }
    @Test fun safetyFiltersAreStillEnabled() {
        val p=Profile(injuryZones=setOf(Zone.KNEE),risk=Risk.MILD)
        val plan=Planner.plan(p,0)
        assertEquals(PlanStatus.READY,plan.status)
        assertTrue(plan.items.all{Zone.KNEE !in it.exercise.involved && Zone.KNEE !in it.exercise.supports})
        assertEquals(PlanStatus.REQUIRES_REVIEW, Planner.plan(p.copy(risk=Risk.SEVERE),0).status)
    }
}
