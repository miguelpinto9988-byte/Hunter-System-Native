# Decisiones de arquitectura

1. UI Compose pura y Canvas nativo. Sin WebView, JavaScript/HTML/CSS ejecutados, ni Unity.
2. Animaciones: phase(elapsedNanoTime, durationMs, speed). Se interpolan las coordenadas entre dos fotogramas más próximos para reducir saltos. Los FPS dependen del compositor del dispositivo; el tiempo de un ciclo no depende de FPS.
3. Datos: DataStore para perfil y logs pequeños. Migrar logs voluminosos a Room en siguiente iteración para operaciones por registro.
4. Cuidados: una restricción sobre articulación afecta tanto articulaciones que se mueven como las que soportan el ejercicio. La ausencia de articulaciones marcadas no demuestra seguridad clínica.
5. Planificación: separación entre sesión programada, ejercicio seleccionado y log. No reescribir el historial al guardar un perfil.
6. Responsive: columnas desplazables, modal con `widthIn(max=720.dp)` y `heightIn` según el dispositivo; rail a partir de 700 dp.
7. Optimización: index de 1000 modelos en arranque, archivos de animación leídos individualmente solo cuando se abre una ficha.
8. Acompañantes: prototipos vectoriales Canvas genéricos etiquetados según selección; se requiere migración gráfica completa antes de llamarlos equivalentes a V38.0.
9. La app nativa usa paquete propio para coexistir con V38.0. Importación de respaldo solicitada expresamente y vista previa antes de alterar datos.
10. No hay resultados de FPS en Android, tampoco auditoría por fabricante/modelo.
