# Hunter System V39.2 — Proyecto Kotlin Android nativo, COMPILACIÓN PENDIENTE

**Estado:** Código fuente Android/Jetpack Compose. No es una APK y no se afirma paridad funcional con V38.0.

**GitHub:** La cuenta vinculada a esta conversación no expone repositorios ni instalaciones a la integración, por lo que no ha sido posible subir el proyecto ni ejecutar GitHub Actions. Crea un repositorio privado y concede acceso a la integración; luego confirma el repositorio `usuario/nombre`.

**Correcciones respecto de V39.1:**
- Se interpreta correctamente el calendario importado desde V38.0: domingo-primer-día pasa a lunes-primer-día.
- Se registra el inicio de un ciclo de tres semanas y se calcula igual desde Panel, Misiones, Rutinas y la ventana de cada misión.
- El planificador analiza esfuerzo/dolor/fatiga registrados en los siete días previos al día seleccionado para ajustar conservadoramente el volumen, en lugar de mirar solo el registro del día.
- Se informa error de carga de demostraciones, en vez de mostrar un spinner indefinido.
- El importador ahora admite tanto respaldos V38 como los respaldos nativos V39 generados por «Exportar copia», que antes no podían restaurarse.
- El workflow agrega pruebas JUnit del calendario y del planificador previas a la compilación.

# Hunter System V39.2 — Código Android nativo y compilación automatizada

> **Estado comprobado:** proyecto fuente Kotlin/Jetpack Compose. **NO SE HA GENERADO UNA APK** en este entorno. No hay SDK Android 35, Gradle, ADB, emulador ni acceso a repositorios de dependencias. El flujo de GitHub Actions permite realizar una compilación de depuración en una máquina preparada, **pero todavía no se ha ejecutado** y puede necesitar depuración.

## Contenido

- Arquitectura de código Android nativa: Activity + Jetpack Compose, sin WebView ni Unity.
- Seis pantallas: Panel, Misiones, Rutinas, Ejercicios, Progreso y Perfil.
- Se han trasladado 1000 conjuntos de movimientos 2D a archivos JSON usados por un visor `Canvas` nativo, con duraciones relativas al reloj real e interpolación. La revisión visual de posturas sigue pendiente.
- Cinco retratos originales de Igris, Iron, Tank, Beru y Dokja Kim del APK V38, dibujados con `Image` nativo y animación de espera. Se trata de imágenes 2D: las animaciones articuladas originales de cada personaje todavía no se han portado por completo.
- Planificación por día (Fuerza, Cardio, Movilidad, Descanso), metas, equipamiento, intensidad y zona de lesión, con 38 ejercicios **catalogados para planificación**. No se deben ofrecer ejercicios cuando el perfil indica riesgo agudo o grave sin revisión individual.
- Perfil persistente con DataStore, progreso E–S, misiones y notas.
- Importador de respaldo V38 mediante selección de archivo (no automática) que ahora conserva notas, RPE, series, repeticiones y cargas declaradas, cuando están presentes. La economía de progreso, las fotografías, las notificaciones y otros datos antiguos no están convertidos totalmente. **Conserva el JSON original exportado desde V38.**
- Mejora V39.2: los controles Pausar/Reanudar y 0,5×/1×/1,5× conservan la fase del movimiento al cambiar la velocidad en lugar de reiniciar el ciclo.
- Refuerzo de privacidad: se desactiva la copia automática en la nube del almacenamiento de perfil, que contiene información de lesiones y molestias.
- Android se encarga de recrear la Activity al rotar para activar diseño responsive de Compose.

## Resultados reproducidos localmente

```bash
bash tools/run_native_logic_tests.sh
```

Incluye pruebas del planificador Kotlin y de los 1000 archivos de movimiento. Todas esas pruebas locales pasan. **No son pruebas de compilación Android, interfaz ni FPS físicos.**

## Obtener la APK nativa (Android Studio)

1. Abrir esta carpeta en Android Studio con JDK 17, Android SDK 35 y conexión a Google Maven/Maven Central.
2. Sincronizar Gradle. Los plugins están en `build.gradle.kts` (AGP 8.9.2, Kotlin 2.1.20) y la versión requerida es Gradle 8.11.1.
3. Ejecutar `gradle :app:assembleDebug` o *Build > Build APK(s)* una vez configurado Gradle.
4. Si la compilación termina correctamente, la APK aparece en `app/build/outputs/apk/debug/app-debug.apk`.
5. Instalar **sin borrar V38**, exportar respaldo desde V38 e importarlo en Perfil > Importar V38. Revisar que calendario y lesiones coincidan con los datos originales.

## Compilación automática en GitHub (sin Android Studio local)

1. Crea un repositorio **privado** en GitHub y sube el contenido de esta carpeta (no solamente el archivo ZIP). No subas respaldos personales ni claves privadas.
2. Abre la pestaña **Actions** > **Compilar APK nativa Hunter System** > **Run workflow**.
3. El flujo `.github/workflows/compilar-apk-nativa.yml` instala Java/Android SDK/Gradle, intenta compilar y verifica el ZIP APK resultante.
4. Si termina con éxito, descarga el artefacto **Hunter-System-V39.2-APK-debug-nativa** desde esa ejecución. Si falla, lee el registro del paso de compilación; este flujo no simula éxito.

La APK de depuración usa una firma temporal: **no sirve como clave de producción**, ni sustituye automáticamente el paquete V38. El ID sigue siendo `com.huntersystem.native`.

## Pendientes para paridad completa con V38

1. Ejecutar la compilación Android real y depurar integración Compose/Gradle si la hay.
2. Realizar pruebas de instalación, rotación, persistencia, accesibilidad, memoria, batería y FPS con `adb`/Perfetto.
3. Trasladar las animaciones y efectos avanzados de cada avatar, y las rutinas por entrenador, recordatorios, notificaciones y todo el catálogo de ejercicios bajo clasificación individual.
4. Revisar las 1000 posturas 2D con criterio biomecánico y no prescribir actividad basándose solo en etiquetas de articulaciones.
5. Completar migración de imágenes de usuario, métricas personalizadas, ciclos y otras estructuras de V38; validar con una copia real aportada por el usuario y **sin exponer sus datos personales**.
6. En una app de producción, evaluar Room/SQLite para historiales crecientes y pruebas de regresión de interfaz.

**No se afirma equivalencia funcional total con V38, FPS de 90/120 ni APK compilada.**
