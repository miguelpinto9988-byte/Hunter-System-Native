#!/usr/bin/env bash
set -euo pipefail
PKG='com.huntersystem.native'
command -v adb >/dev/null || { echo 'ADB unavailable: install Android platform-tools'; exit 1; }
echo 'Device:';adb shell dumpsys display | grep -i -m 4 -E 'modes|refreshRate' || true
adb shell am force-stop "$PKG" || true
adb shell am start -n "$PKG/com.huntersystem.nativeapp.MainActivity"
sleep 2
adb shell dumpsys gfxinfo "$PKG" reset
printf '\nInteract with navigation and animations for ~30 seconds. Then press Enter.';read -r _
mkdir -p results
adb shell dumpsys gfxinfo "$PKG" framestats > results/gfxinfo-framestats.txt
adb shell dumpsys meminfo "$PKG" > results/meminfo.txt
printf 'Frames saved. 90 FPS theoretical budget is 11.11 ms; 120 FPS is 8.33 ms. Use Perfetto FrameTimeline for displayed frames.\n'
