#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)";trap 'rm -rf "$WORK"' EXIT
kotlinc "$DIR"/app/src/main/java/com/huntersystem/nativeapp/domain/*.kt "$DIR/tools/tests/EngineTests.kt" -include-runtime -d "$WORK/tests.jar"
java -Dfile.encoding=UTF-8 -jar "$WORK/tests.jar"
python3 "$DIR/tools/verify_project.py"
