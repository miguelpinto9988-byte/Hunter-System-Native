#!/usr/bin/env python3
"""Convert the user-owned V38.0 APK skeletal motion JSON to native Canvas input.
The script does not execute, bundle or depend on JavaScript/WebView.
"""
import argparse, json, zipfile
from pathlib import Path

def extract(apk: Path, dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(apk) as z:
        manifest=json.loads(z.read('assets/demo-manifest-v30.json'))
        entry=[]; issues=[]
        for id, info in manifest['exercises'].items():
            try:
                obj=json.loads(z.read('assets/'+info['model']))
                frames=[]
                for frame in obj['frames']:
                    pts=frame['p']
                    if len(pts)<11 or any(len(p)!=2 for p in pts):raise ValueError('pose missing points')
                    frames.append([[round(float(a),1),round(float(b),1)] for a,b in pts[:11]])
                if len(frames)<2 or not (0.5<=float(info['duration'])<=60):raise ValueError('invalid timing')
                dst={'id':id,'name':obj.get('name',id),'durationMs':round(float(info['duration'])*1000),'frames':frames}
                (dest/f'{id}.json').write_text(json.dumps(dst,ensure_ascii=False,separators=(',',':')),'utf-8')
                entry.append({'id':id,'name':obj.get('name',id),'durationMs':dst['durationMs']})
            except (KeyError,ValueError,TypeError,UnicodeDecodeError,json.JSONDecodeError) as exc:issues.append(f'{id}: {exc}')
        (dest.parent/'motion_index.json').write_text(json.dumps(entry,ensure_ascii=False,separators=(',',':')),'utf-8')
        return len(entry), issues
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('apk',type=Path);ap.add_argument('destination',type=Path);a=ap.parse_args();n,e=extract(a.apk,a.destination);print(f'importados={n} rechazados={len(e)}');print('\n'.join(e[:30]));raise SystemExit(bool(e))
