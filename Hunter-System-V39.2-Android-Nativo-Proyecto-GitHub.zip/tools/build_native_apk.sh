#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v sdkmanager >/dev/null 2>&1 && [ ! -d "${ANDROID_HOME:-/nonexistent}/platforms/android-35" ]; then
  echo "FALTA EL SDK ANDROID 35: compila en Android Studio o en GitHub Actions" >&2
  exit 2
fi
if command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon :app:assembleDebug
elif [ -x ./gradlew ] && [ -f ./gradle/wrapper/gradle-wrapper.jar ]; then
  ./gradlew --no-daemon :app:assembleDebug
else
  echo "FALTA GRADLE: usa CI .github/workflows/compilar-apk-nativa.yml" >&2
  exit 2
fi
APK=app/build/outputs/apk/debug/app-debug.apk
test -s "$APK" && unzip -t "$APK" >/dev/null && echo "APK compilada: $APK"
