#!/usr/bin/env python3
"""Static source and imported animation quality checks, not an Android runtime test."""
from pathlib import Path
import json,re,sys,collections
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java'
assets=root/'app/src/main/assets'
errors=[];warnings=[]
kt=list(src.rglob('*.kt'))
print('Kotlin sources:',len(kt))
if any(re.search(r'\b(android\.webkit\.WebView|WebView\(|loadUrl\(|WebViewClient)\b',x.read_text(encoding='utf8')) for x in kt):errors.append('WebView usage found')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
if 'INTERNET' in manifest:warnings.append('Internet permission declared (expected offline-only)')
motions=json.loads((assets/'motion_index.json').read_text(encoding='utf8'))
ids=set();durations=collections.Counter();counts=[]
for item in motions:
 ident=item['id'];time=item['durationMs']
 if ident in ids:errors.append('Duplicate motion id '+ident)
 ids.add(ident);durations[time]+=1
 path=assets/'motions'/f'{ident}.json'
 if not path.is_file():errors.append('Missing '+str(path));continue
 motion=json.loads(path.read_text(encoding='utf8'))
 frames=motion['frames'];counts.append(len(frames))
 if not 0.5*1000<=time<=60*1000:errors.append('Bad duration '+ident)
 if len(frames)<2 or any(len(pts)!=11 or any(len(p)!=2 or any(not isinstance(v,(int,float)) for v in p) for p in pts) for pts in frames):errors.append('Invalid poses '+ident)
 if motion['durationMs']!=time:errors.append('Duration index mismatch '+ident)
print('Imported native models:',len(ids),'frames min/max:',min(counts),max(counts),'duration distribution (ms):',durations)
portraits=list((root/'app/src/main/res/drawable-nodpi').glob('hunter_companion_*.webp'))
if len(portraits)!=5:errors.append(f'Expected 5 native portraits; got {len(portraits)}')
else:
 print('Original companion art migrated:',len(portraits),'in drawable-nodpi')
if len(ids)!=1000:warnings.append(f'Original manifest has 1000 models; imported {len(ids)}')
if not (root/'app/src/main/java/com/huntersystem/nativeapp/data/LegacyMigration.kt').is_file():errors.append('Legacy importer missing')
if not (root/'app/src/main/java/com/huntersystem/nativeapp/ui/ProfileScreen.kt').is_file():errors.append('Profile screen missing')
print('WebView API:', 'ABSENT' if not errors else 'CHECK')
print('Warnings:',warnings)
print('Errors:',errors)
if errors:sys.exit(1)
