# Estado real — Hunter System nativo V39.2 (17-10-2026)

## Comprobado en esta sesión

- 15 archivos fuente Kotlin; no se encontró ninguna referencia a `android.webkit.WebView` en esos fuentes.
- 1000 archivos JSON de movimiento y sus metadatos de duración se validaron con `tools/verify_project.py`.
- Cinco retratos de acompañante existen como recursos gráficos nativos.
- Se corrigió la importación del calendario V38: la app antigua usa domingo como día 0, la nueva usa lunes como día 0.
- Las tres semanas de calendario quedan ancladas al lunes del primer guardado de perfil; los calendarios y la misión seleccionada utilizan el mismo cálculo.
- Las sesiones registradas en los últimos 7 días pueden reducir, sin aumentar, las series propuestas cuando contienen fatiga, dolor o esfuerzo alto.
- Ahora se admite restaurar exportaciones nativas V39 además de respaldos V38.
- Las pruebas del motor Kotlin con `kotlinc` pasaron, junto con validaciones de archivos de movimiento.

## No verificado o no entregado todavía

- **APK nativa compilada/firmada/instalada:** no realizada. No hay SDK/Gradle Android en este entorno y el conector GitHub no muestra ningún repositorio ni instalación accesible.
- **GitHub Actions**: se preparó el workflow, pero no se puede ejecutarlo hasta que la integración de GitHub tenga acceso a un repositorio real con el código.
- **Paridad completa V38 → V39**: pendiente. Se transportaron 1000 demostraciones visuales, pero solo 38 ejercicios tienen metadatos aptos para planificación; no se portaron todas las rutinas, todos los avatares articulados, todas las métricas, la fotografía personal ni las notificaciones.
- **90/120 FPS, fluidez y posturas**: no medidos ni verificados en un teléfono Android real.
- **Restauración de un respaldo real V38**: el esquema fue revisado estáticamente, pero falta una exportación de prueba no sensible para una prueba de integración.

## Para habilitar la compilación en GitHub

1. Crea un repositorio **privado** vacío, por ejemplo `Hunter-System-Native` (sin secretos, datos personales ni claves de firma).
2. Autoriza en la conexión GitHub de ChatGPT el acceso de la integración a ese repositorio.
3. Indica en el chat su identificador `propietario/Hunter-System-Native`. Podré comprobar el acceso y publicar el código.
4. Al recibir la rama `main`, el archivo `.github/workflows/compilar-apk-nativa.yml` intenta ejecutar pruebas y `:app:assembleDebug`.
5. Solo tras un workflow con resultado `success` y una APK real subida como artefacto podrá afirmarse que existe una compilación descargable. Después habrá que instalarla en Android y comprobar sus funciones y FPS.

No publiques el archivo de firma privada `.p12` ni la contraseña de versiones anteriores.
